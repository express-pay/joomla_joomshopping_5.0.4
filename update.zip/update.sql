INSERT INTO `#__jshopping_payment_method` 
(`payment_code`, 
`scriptname`, 
`payment_class`, 
`payment_publish`, 
`payment_ordering`,
`payment_params`,  
`payment_type`, 
`price`, 
`price_type`,
`tax_id`, 
`show_descr_in_email`, 
`name_en-GB`, 
`name_de-DE`,
 `name_ru-RU`) 
 VALUES 
 ('expresspay', 
 'pm_expresspay', 
 'pm_expresspay', 
 1, 
 0,
'expresspay_service_id=
expresspay_token=
expresspay_secret_key=
expresspay_secret_key_notify=
expresspay_url_api=https://api.express-pay.by
expresspay_url_sandbox_api=https://sandbox-api.express-pay.by
transaction_end_status=1
transaction_pending_status=1
transaction_failed_status=1', 
 2, 
 0.00, 
 0, 
 1, 
 0, 
 'Service "Express Payment"', 
 'Service "Express Payment"', 
 'Сервис "Экспресс Платежи"'
 );
DROP TABLE IF EXISTS `#__jshopping_payment_express_pay`;
CREATE TABLE `#__jshopping_payment_express_pay` (`ru` TEXT, `en` TEXT);
INSERT INTO `#__jshopping_payment_express_pay` (`ru`, `en`) VALUES ('Ваш номер заказа "##order_id##"', 'Your order number "##order_id##"');